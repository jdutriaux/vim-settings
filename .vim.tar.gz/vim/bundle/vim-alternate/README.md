alternate.vim
=============

Alternate between .c and .h files quickly

Note: I am not the author of this script; merely hosting it here to easily keep
all my distributed vimconfigs up to date.


Copyright (c) 1998-2006
Michael Sharpe <feline@irendi.com>

We grant permission to use, copy modify, distribute, and sell this
software for any purpose without fee, provided that the above copyright
notice and this text are not removed. We make no guarantee about the
suitability of this software for any purpose and we are not liable
for any damages resulting from its use. Further, we are under no
obligation to maintain or extend this software. It is provided on an
"as is" basis without any expressed or implied warranty.

Directory & regex enhancements added by Bindu Wavell who is well known on
vim.sf.net

Patch for spaces in files/directories from Nathan Stien (also reported by
Soeren Sonnenburg)


