:orphan:

powerline-daemon manual page
============================

.. automan:: powerline.commands.daemon
   :prog: powerline-daemon

See also
--------

:manpage:`powerline(1)`
