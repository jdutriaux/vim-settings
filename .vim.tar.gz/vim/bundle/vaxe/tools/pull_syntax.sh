git fetch vimsyntax master
git subtree pull --prefix=syntax --squash vimsyntax master
