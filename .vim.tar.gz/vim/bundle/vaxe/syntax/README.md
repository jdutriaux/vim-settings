There are a few vim plugins for Haxe:  
1) [vaxe](https://github.com/jdonaldson/vaxe)
2) [vim-haxe](https://github.com/MarcWeber/vim-haxe)

This syntax file serves as a common form for syntax highlighting.
