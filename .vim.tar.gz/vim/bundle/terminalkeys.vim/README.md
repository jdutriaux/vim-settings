terminalkeys.vim
================

Some things to improve key support in rxvt, taken from https://github.com/godlygeek/vim-files/blob/master/plugin/terminalkeys.vim